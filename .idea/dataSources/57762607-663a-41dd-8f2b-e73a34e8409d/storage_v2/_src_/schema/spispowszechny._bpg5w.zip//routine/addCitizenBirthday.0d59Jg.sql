create
    definer = root@localhost procedure addCitizenBirthday(IN pesel varchar(11))
BEGIN
    INSERT INTO birthdays VALUES (pesel, extractDayOfBirth(pesel),
                                  extractMonthOfBirth(pesel), extractYearOfBirth(pesel));
END;

