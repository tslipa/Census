create
    definer = root@localhost function getCitizenStreet(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT A.street
        FROM addresses A
        WHERE A.pesel = pesel);
END;

