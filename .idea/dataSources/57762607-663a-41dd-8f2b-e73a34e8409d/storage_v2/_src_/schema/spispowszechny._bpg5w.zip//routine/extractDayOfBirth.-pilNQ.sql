create
    definer = root@localhost function extractDayOfBirth(pesel varchar(11)) returns int
BEGIN
    RETURN SUBSTRING(pesel, 5, 2);
END;

