create
    definer = root@localhost function extractYearOfBirth(pesel varchar(11)) returns int
BEGIN
    IF (SUBSTRING(pesel, 3, 1) = '2' || SUBSTRING(pesel, 3, 1) = '3') THEN
        RETURN LEFT(pesel, 2) + 2000;
    ELSE
        RETURN LEFT(pesel, 2) + 1900;
    END IF;
END;

