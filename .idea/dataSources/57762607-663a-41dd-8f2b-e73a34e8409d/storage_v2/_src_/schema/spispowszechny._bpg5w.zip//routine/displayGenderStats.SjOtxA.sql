create
    definer = root@localhost procedure displayGenderStats(IN sgender varchar(32), OUT result int)
BEGIN
    SELECT GS.quantity INTO result
    FROM genderstats GS
    WHERE GS.gender = sgender;
END;

