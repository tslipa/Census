create
    definer = root@localhost procedure addCity(IN city varchar(32))
BEGIN
    INSERT INTO citystats (name, population)
    VALUES (city, 0);
END;

