create
    definer = root@localhost procedure addCitizenAddress(IN pesel varchar(11), IN city varchar(32),
                                                         IN street varchar(32), IN house int, IN flat int)
BEGIN
    PREPARE stmt FROM 'INSERT INTO addresses VALUES (?, ?, ?, ?, ?)';
    EXECUTE stmt USING pesel, city, street, house, flat;
    DEALLOCATE PREPARE stmt;
END;

