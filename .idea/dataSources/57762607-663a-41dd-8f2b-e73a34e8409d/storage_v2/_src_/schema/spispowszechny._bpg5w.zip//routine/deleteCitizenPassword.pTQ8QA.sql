create
    definer = root@localhost procedure deleteCitizenPassword(IN delPesel varchar(11))
BEGIN
    DELETE FROM passwords WHERE pesel = delPesel;
END;

