create definer = root@localhost trigger tUpdateCityStats
    after update
    on addresses
    for each row
BEGIN
    UPDATE citystats
        SET population = population - 1
        WHERE name = OLD.city;

    IF (cityExists(NEW.city) = 0) THEN
        CALL addCity(NEW.city);
    END IF;

    UPDATE citystats
        SET population = population + 1
        WHERE name = NEW.city;
END;

