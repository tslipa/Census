create definer = root@localhost trigger tExtractCitizenData
    after insert
    on citizens
    for each row
BEGIN
    DECLARE newPesel VARCHAR(11) DEFAULT NEW.pesel;

    CALL addCitizenGender(newPesel);

    UPDATE genderstats GS
        JOIN genders G ON GS.gender = G.gender
        SET GS.quantity = GS.quantity + 1
        WHERE G.pesel = newPesel;

    IF (yearExists(extractYearOfBirth(newPesel)) = 0) THEN
        CALL addYear(extractYearOfBirth(newPesel));
    END IF;

    CALL addCitizenBirthday(newPesel);

    UPDATE yearstats YS
        JOIN birthdays B ON YS.year = B.yearOfBirth
        SET YS.quantity = YS.quantity + 1
        WHERE B.pesel = newPesel;
END;

