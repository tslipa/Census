create
    definer = root@localhost function getCitizenHouse(pesel varchar(11)) returns int
BEGIN
    RETURN (SELECT A.house
        FROM addresses A
        WHERE A.pesel = pesel);
END;

