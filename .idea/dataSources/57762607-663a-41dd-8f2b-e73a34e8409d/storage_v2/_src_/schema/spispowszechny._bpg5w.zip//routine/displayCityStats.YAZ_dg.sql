create
    definer = root@localhost procedure displayCityStats(IN city varchar(32), OUT result int)
BEGIN
    SELECT CS.population INTO result
    FROM citystats CS
    WHERE CS.name = city;
END;

