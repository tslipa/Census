create
    definer = root@localhost procedure deleteCitizenAddress(IN delPesel varchar(11))
BEGIN
    DELETE FROM addresses WHERE pesel = delPesel;
END;

