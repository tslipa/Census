create
    definer = root@localhost function getStatus(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT S.status
        FROM statuses S
        WHERE S.pesel = pesel);
END;

