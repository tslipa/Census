create
    definer = root@localhost function getCitizenFlat(pesel varchar(11)) returns int
BEGIN
    RETURN (SELECT A.flat
        FROM addresses A
        WHERE A.pesel = pesel);
END;

