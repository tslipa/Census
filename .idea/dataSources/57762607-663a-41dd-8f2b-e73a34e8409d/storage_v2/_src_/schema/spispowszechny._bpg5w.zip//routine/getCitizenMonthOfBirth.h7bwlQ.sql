create
    definer = root@localhost function getCitizenMonthOfBirth(pesel varchar(11)) returns int
BEGIN
    RETURN (SELECT B.monthOfBirth
        FROM birthdays B
        WHERE B.pesel = pesel);
END;

