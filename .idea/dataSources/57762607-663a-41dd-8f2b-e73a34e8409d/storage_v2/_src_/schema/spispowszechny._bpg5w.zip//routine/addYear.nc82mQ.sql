create
    definer = root@localhost procedure addYear(IN year int)
BEGIN
    INSERT INTO yearstats (year, quantity)
    VALUES (year, 0);
END;

