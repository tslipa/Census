create
    definer = root@localhost function getCitizenDayOfBirth(pesel varchar(11)) returns int
BEGIN
     RETURN (SELECT B.dayOfBirth
        FROM birthdays B
        WHERE B.pesel = pesel);
END;

