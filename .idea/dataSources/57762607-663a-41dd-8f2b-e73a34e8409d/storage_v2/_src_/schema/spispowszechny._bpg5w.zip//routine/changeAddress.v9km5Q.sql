create
    definer = root@localhost procedure changeAddress(IN pesel varchar(11), IN city varchar(32), IN street varchar(32),
                                                     IN house int, IN flat int)
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;
        IF (pesel REGEXP '^[0-9]+$' AND LENGTH(pesel) = 11 AND citizenExists(pesel) = 0) THEN
            PREPARE stmt FROM 'UPDATE addresses A
                               SET A.city = ?, A.street = ?, A.house = ?, A.flat = ?
                               WHERE A.pesel = ?;';
            EXECUTE stmt USING city, street, house, flat, pesel;
            DEALLOCATE PREPARE stmt;
        END IF;
    COMMIT;
END;

