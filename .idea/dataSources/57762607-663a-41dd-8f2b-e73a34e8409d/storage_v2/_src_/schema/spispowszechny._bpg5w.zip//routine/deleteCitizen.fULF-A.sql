create
    definer = root@localhost procedure deleteCitizen(IN pesel varchar(11), IN status varchar(32),
                                                     OUT result varchar(60))
BEGIN
    IF (citizenExists(pesel) AND getStatus(pesel) = status) THEN
        PREPARE stmt FROM 'DELETE FROM citizens WHERE pesel = ?';
        EXECUTE stmt USING pesel;
        DEALLOCATE PREPARE stmt;
        SELECT 'This citizen has been deleted.' INTO result;
    ELSE
        SELECT 'This citizen does not exist or cant be deleted.' INTO result;
    END IF;
END;

