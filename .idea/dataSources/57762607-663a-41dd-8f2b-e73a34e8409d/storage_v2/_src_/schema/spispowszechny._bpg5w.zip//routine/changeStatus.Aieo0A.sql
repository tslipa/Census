create
    definer = root@localhost procedure changeStatus(IN spesel varchar(11), IN newStatus varchar(32))
BEGIN
    IF (getStatus(spesel) = 'Citizen' OR getStatus(spesel) = 'Bureaucrat') THEN
        UPDATE statuses
            SET status = newStatus
            WHERE pesel = spesel;
    END IF;
END;

