create
    definer = root@localhost function checkPassword(pesel varchar(11), password varchar(32)) returns int
BEGIN
    RETURN EXISTS(SELECT *
    FROM passwords P
    WHERE P.pesel = pesel AND P.password = md5(password));
END;

