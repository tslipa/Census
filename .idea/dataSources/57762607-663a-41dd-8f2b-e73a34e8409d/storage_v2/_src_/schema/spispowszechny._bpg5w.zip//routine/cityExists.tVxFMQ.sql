create
    definer = root@localhost function cityExists(city varchar(32)) returns int
BEGIN
    RETURN EXISTS(SELECT * FROM citystats C WHERE C.name = city);
END;

