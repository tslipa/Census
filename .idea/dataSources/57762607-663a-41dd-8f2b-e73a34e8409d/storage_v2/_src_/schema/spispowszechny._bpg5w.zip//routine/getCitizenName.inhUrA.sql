create
    definer = root@localhost function getCitizenName(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT C.name
        FROM citizens C
        WHERE C.pesel = pesel);
END;

