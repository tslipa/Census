create
    definer = root@localhost function getCitizenYearOfBirth(pesel varchar(11)) returns int
BEGIN
    RETURN (SELECT B.yearOfBirth
        FROM birthdays B
        WHERE B.pesel = pesel);
END;

