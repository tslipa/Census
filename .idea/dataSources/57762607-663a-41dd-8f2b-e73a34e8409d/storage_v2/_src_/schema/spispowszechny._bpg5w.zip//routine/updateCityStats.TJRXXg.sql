create
    definer = root@localhost procedure updateCityStats(IN oldCity varchar(32), IN newCity varchar(32))
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;

    UPDATE citystats
        SET population = population - 1
        WHERE name = oldCity;
    UPDATE citystats
        SET population = population + 1
        WHERE name = newCity;

    COMMIT;
END;

