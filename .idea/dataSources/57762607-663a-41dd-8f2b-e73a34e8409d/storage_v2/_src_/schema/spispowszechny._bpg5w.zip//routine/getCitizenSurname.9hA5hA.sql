create
    definer = root@localhost function getCitizenSurname(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT C.surname
        FROM citizens C
        WHERE C.pesel = pesel);
END;

