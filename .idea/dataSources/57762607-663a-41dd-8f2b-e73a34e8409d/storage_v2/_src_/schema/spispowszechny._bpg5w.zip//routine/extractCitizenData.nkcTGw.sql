create
    definer = root@localhost procedure extractCitizenData(IN newPesel varchar(11))
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;

    UPDATE citystats CS
        JOIN addresses A ON CS.name = A.city
        SET CS.population = CS.population + 1
        WHERE A.pesel = newPesel;

    CALL addCitizenGender(newPesel);
    UPDATE genderstats GS
        JOIN genders G ON GS.gender = G.gender
        SET GS.quantity = GS.quantity + 1
        WHERE G.pesel = newPesel;

    CALL addCitizenBirthday(newPesel);
    UPDATE yearstats YS
        JOIN birthdays B ON YS.year = B.yearOfBirth
        SET YS.quantity = YS.quantity + 1
        WHERE B.pesel = newPesel;

    COMMIT;
END;

