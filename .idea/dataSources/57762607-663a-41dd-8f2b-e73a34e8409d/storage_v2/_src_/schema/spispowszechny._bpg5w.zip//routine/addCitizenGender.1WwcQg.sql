create
    definer = root@localhost procedure addCitizenGender(IN pesel varchar(11))
BEGIN
    INSERT INTO genders VALUES (pesel, extractGender(pesel));
END;

