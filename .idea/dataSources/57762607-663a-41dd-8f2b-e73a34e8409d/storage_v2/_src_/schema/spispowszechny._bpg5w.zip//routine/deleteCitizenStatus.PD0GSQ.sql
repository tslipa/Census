create
    definer = root@localhost procedure deleteCitizenStatus(IN delPesel varchar(11))
BEGIN
    DELETE FROM statuses WHERE pesel = delPesel;
END;

