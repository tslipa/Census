create
    definer = root@localhost function getCitizenCity(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT A.city
        FROM addresses A
        WHERE A.pesel = pesel);
END;

