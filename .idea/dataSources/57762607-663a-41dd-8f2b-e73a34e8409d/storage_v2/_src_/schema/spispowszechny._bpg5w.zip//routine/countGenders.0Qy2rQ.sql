create
    definer = root@localhost function countGenders(gender varchar(32)) returns int
BEGIN
    RETURN (SELECT COUNT(G.pesel)
        FROM genders G
        WHERE G.gender = gender
        GROUP BY G.gender);
END;

