create
    definer = root@localhost procedure correctLoginData(IN spesel varchar(11), IN spassword varchar(32), OUT result int)
BEGIN
    IF (checkPassword(spesel, spassword)) THEN
        SELECT '1' INTO result;
    ELSE
        SELECT '0' INTO result;
    END IF;
END;

