create
    definer = root@localhost procedure displayStatus(IN spesel varchar(11), OUT result varchar(32))
BEGIN
    SELECT S.status INTO result
    FROM statuses S
    WHERE S.pesel = spesel;
END;

