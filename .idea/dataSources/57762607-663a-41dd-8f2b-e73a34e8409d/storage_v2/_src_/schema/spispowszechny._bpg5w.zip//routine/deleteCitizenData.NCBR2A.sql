create
    definer = root@localhost procedure deleteCitizenData(IN delPesel varchar(11))
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;

    DELETE FROM passwords WHERE pesel = delPesel;
    DELETE FROM statuses WHERE pesel = delPesel;

    UPDATE yearstats YS
        JOIN birthdays B ON YS.year = B.yearOfBirth
        SET YS.quantity = YS.quantity - 1
        WHERE B.pesel = delPesel;
    DELETE FROM birthdays WHERE pesel = delPesel;

    UPDATE genderstats GS
        JOIN genders G ON GS.gender = G.gender
        SET GS.quantity = GS.quantity - 1
        WHERE pesel = delPesel;
    DELETE FROM genders WHERE pesel = delPesel;

    UPDATE citystats CS
        JOIN addresses A ON CS.name = A.city
        SET CS.population = CS.population - 1
        WHERE A.pesel = delPesel;
    DELETE FROM addresses WHERE pesel = delPesel;

    COMMIT;
END;

