create
    definer = root@localhost function yearExists(year int) returns int
BEGIN
    RETURN EXISTS(SELECT * FROM yearstats Y WHERE Y.year = year);
END;

