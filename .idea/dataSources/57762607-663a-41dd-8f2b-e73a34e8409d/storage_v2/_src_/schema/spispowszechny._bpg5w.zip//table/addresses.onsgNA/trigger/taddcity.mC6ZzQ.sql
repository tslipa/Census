create definer = root@localhost trigger tAddCity
    before insert
    on addresses
    for each row
BEGIN
    IF (cityExists(NEW.city) = 0) THEN
        CALL addCity(NEW.city);
    END IF;

    UPDATE citystats CS
        SET CS.population = CS.population + 1
        WHERE name = NEW.city;
END;

