create
    definer = root@localhost function extractMonthOfBirth(pesel varchar(11)) returns int
BEGIN
    IF (SUBSTRING(pesel, 3, 1) = '2' || SUBSTRING(pesel, 3, 1) = '3') THEN
        RETURN SUBSTRING(pesel, 3, 2) - 20;
    ELSE
        RETURN SUBSTRING(pesel, 3, 2);
    END IF;
END;

