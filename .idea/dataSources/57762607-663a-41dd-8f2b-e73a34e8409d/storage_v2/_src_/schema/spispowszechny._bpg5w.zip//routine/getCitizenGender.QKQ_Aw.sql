create
    definer = root@localhost function getCitizenGender(pesel varchar(11)) returns varchar(32)
BEGIN
    RETURN (SELECT G.gender
        FROM genders G
        WHERE G.pesel = pesel);
END;

