create
    definer = root@localhost function citizenExists(pesel varchar(11)) returns int
BEGIN
    RETURN EXISTS(SELECT * FROM citizens C WHERE C.pesel = pesel);
END;

