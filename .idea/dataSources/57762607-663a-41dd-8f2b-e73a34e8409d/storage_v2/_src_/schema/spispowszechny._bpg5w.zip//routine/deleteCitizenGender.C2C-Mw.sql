create
    definer = root@localhost procedure deleteCitizenGender(IN delPesel varchar(11))
BEGIN
    DELETE FROM genders WHERE pesel = delPesel;
END;

