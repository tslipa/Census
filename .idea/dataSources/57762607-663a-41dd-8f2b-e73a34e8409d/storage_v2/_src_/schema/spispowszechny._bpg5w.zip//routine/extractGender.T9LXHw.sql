create
    definer = root@localhost function extractGender(pesel varchar(11)) returns varchar(32)
BEGIN
    IF (SUBSTRING(pesel, 10, 1) % 2 = 0) THEN
        RETURN 'Woman';
    ELSE
        RETURN 'Man';
    END IF;
END;

