create
    definer = root@localhost procedure deleteCitizenBirthday(IN delPesel varchar(11))
BEGIN
    DELETE FROM birthdays WHERE pesel = delPesel;
END;

