create
    definer = root@localhost procedure displayYearStats(IN syear int, OUT result int)
BEGIN
    SELECT YS.quantity INTO result
    FROM yearstats YS
    WHERE YS.year = syear;
END;

