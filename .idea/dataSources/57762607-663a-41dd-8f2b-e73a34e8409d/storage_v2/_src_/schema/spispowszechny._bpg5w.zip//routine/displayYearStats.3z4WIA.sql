create
    definer = root@localhost procedure displayYearStats(IN syear int, OUT result int)
BEGIN
    SELECT quantity INTO result
    FROM yearstats
    WHERE year = syear;
END;

