create
    definer = root@localhost function countYears(year int) returns int
BEGIN
    RETURN (SELECT COUNT(B.pesel)
        FROM birthdays B
        WHERE B.yearOfBirth = year
        GROUP BY B.yearOfBirth);
END;

