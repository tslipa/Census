create
    definer = root@localhost procedure printPersonalData(IN pesel varchar(11), OUT result varchar(200))
BEGIN
    DECLARE name VARCHAR(32);
    DECLARE surname VARCHAR(32);
    DECLARE city VARCHAR(32);
    DECLARE street VARCHAR(32);
    DECLARE house INT;
    DECLARE flat INT;

    IF (citizenExists(pesel)) THEN
        SET name = getCitizenName(pesel);
        SET surname = getCitizenSurname(pesel);
        SET city = getCitizenCity(pesel);
        SET street = getCitizenStreet(pesel);
        SET house = getCitizenHouse(pesel);
        SET flat = getCitizenFlat(pesel);

        SELECT CONCAT(name, ' ', surname, ', ', city,  ' ', street, ' ', house, ' ', flat) INTO result;
    ELSE
        SELECT 'This citizen does not exist.' INTO result;
    END IF;
END;

