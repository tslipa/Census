create
    definer = root@localhost procedure changePassword(IN pesel varchar(11), IN oldPassword varchar(32),
                                                      IN newPassword varchar(32))
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;
        IF (pesel REGEXP '^[0-9]+$' AND LENGTH(pesel) = 11 AND checkPassword(pesel, oldPassword) = 1) THEN
            PREPARE stmt FROM 'UPDATE passwords P
                               SET P.password = ?
                               WHERE P.pesel = ?;';
            EXECUTE stmt USING newPassword, pesel;
            DEALLOCATE PREPARE stmt;
        END IF;
    COMMIT;
END;

