create
    definer = root@localhost procedure addCitizenPassword(IN pesel varchar(11), IN password varchar(32))
BEGIN
    PREPARE stmt FROM 'INSERT INTO passwords VALUES (?, ?)';
    EXECUTE stmt USING pesel, password;
    DEALLOCATE PREPARE stmt;
END;

