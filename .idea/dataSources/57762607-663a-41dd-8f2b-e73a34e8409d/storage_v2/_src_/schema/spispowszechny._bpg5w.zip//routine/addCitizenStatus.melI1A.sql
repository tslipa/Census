create
    definer = root@localhost procedure addCitizenStatus(IN pesel varchar(11), IN status varchar(32))
BEGIN
    PREPARE stmt FROM 'INSERT INTO statuses VALUES (?, ?)';
    EXECUTE stmt USING pesel, status;
    DEALLOCATE PREPARE stmt;
END;

