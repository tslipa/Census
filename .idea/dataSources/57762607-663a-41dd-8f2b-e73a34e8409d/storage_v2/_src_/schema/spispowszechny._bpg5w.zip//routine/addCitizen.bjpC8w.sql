create
    definer = root@localhost procedure addCitizen(IN pesel varchar(11), IN password varchar(32), IN status varchar(32),
                                                  IN name varchar(32), IN surname varchar(32), IN city varchar(32),
                                                  IN street varchar(32), IN house int, IN flat int)
BEGIN
    SET AUTOCOMMIT = 0;
    START TRANSACTION;
        IF (pesel REGEXP '^[0-9]+$' AND LENGTH(pesel) = 11 AND citizenExists(pesel) = 0) THEN
            PREPARE stmt FROM 'INSERT INTO citizens VALUES (?, ?, ?)';
            EXECUTE stmt USING pesel, name, surname;
            DEALLOCATE PREPARE stmt;

            CALL addCitizenPassword(pesel, MD5(password));
            CALL addCitizenStatus(pesel, status);
            CALL addCitizenAddress(pesel, city, street, house, flat);
        END IF;
    COMMIT;
END;

